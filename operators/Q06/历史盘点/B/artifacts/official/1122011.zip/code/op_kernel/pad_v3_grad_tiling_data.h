#ifndef PAD_V3_GRAD_TILING_DATA_H
#define PAD_V3_GRAD_TILING_DATA_H
#include <cstdint>
constexpr int64_t PAD_V3_GRAD_MAX_RANK = 32;
// Fixed-width POD shared by the host and kernel. Paddings are read on the host.
struct PadV3GradTilingData {
    int64_t totalInput = 0;
    int64_t totalOutput = 0;
    int64_t blockFactor = 0;
    int64_t ubFactor = 1024;
    int64_t rank = 0;
    int64_t mode = 2;
    int64_t inputShape[PAD_V3_GRAD_MAX_RANK] = {};
    int64_t outputShape[PAD_V3_GRAD_MAX_RANK] = {};
    int64_t inputStride[PAD_V3_GRAD_MAX_RANK] = {};
    int64_t padFront[PAD_V3_GRAD_MAX_RANK] = {};
    // Generated tensor-ABI ACLNN callers may keep padding values on the device.
    int64_t paddingsDtype = 0;       // 0=int32, 1=int64
    int64_t paddingsContiguous = 1;
    int64_t readPaddings = 0;        // 1: kernel loads front values from GM
};
#endif
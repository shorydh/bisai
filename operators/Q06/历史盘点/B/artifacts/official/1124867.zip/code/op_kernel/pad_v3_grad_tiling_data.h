#ifndef PAD_V3_GRAD_TILING_DATA_H
#define PAD_V3_GRAD_TILING_DATA_H
#include <cstddef>
#include <cstdint>
constexpr int64_t PAD_V3_GRAD_MAX_RANK = 32;
// Fixed-width wire POD shared by the host and kernel. No default initialization:
// the host value-initializes it, while the kernel loads only the active axes.
struct PadV3GradTilingData {
    int64_t totalInput;
    int64_t totalOutput;
    int64_t blockFactor;
    int64_t ubFactor;
    int64_t rank;
    int64_t mode;
    int64_t inputShape[PAD_V3_GRAD_MAX_RANK];
    int64_t outputShape[PAD_V3_GRAD_MAX_RANK];
    int64_t inputStride[PAD_V3_GRAD_MAX_RANK];
    int64_t padFront[PAD_V3_GRAD_MAX_RANK];
    // Generated tensor-ABI ACLNN callers may keep padding values on the device.
    int64_t paddingsDtype;       // 0=int32, 1=int64
    int64_t paddingsContiguous;
    int64_t readPaddings;        // 1: kernel loads front values from GM
};
// Keep the established host/device ABI exact, including all unused array slots.
static_assert(sizeof(PadV3GradTilingData) == 1096, "PadV3Grad wire size changed");
static_assert(offsetof(PadV3GradTilingData, totalInput) == 0, "wire offset");
static_assert(offsetof(PadV3GradTilingData, totalOutput) == 8, "wire offset");
static_assert(offsetof(PadV3GradTilingData, blockFactor) == 16, "wire offset");
static_assert(offsetof(PadV3GradTilingData, ubFactor) == 24, "wire offset");
static_assert(offsetof(PadV3GradTilingData, rank) == 32, "wire offset");
static_assert(offsetof(PadV3GradTilingData, mode) == 40, "wire offset");
static_assert(offsetof(PadV3GradTilingData, inputShape) == 48, "wire offset");
static_assert(offsetof(PadV3GradTilingData, outputShape) == 304, "wire offset");
static_assert(offsetof(PadV3GradTilingData, inputStride) == 560, "wire offset");
static_assert(offsetof(PadV3GradTilingData, padFront) == 816, "wire offset");
static_assert(offsetof(PadV3GradTilingData, paddingsDtype) == 1072, "wire offset");
static_assert(offsetof(PadV3GradTilingData, paddingsContiguous) == 1080, "wire offset");
static_assert(offsetof(PadV3GradTilingData, readPaddings) == 1088, "wire offset");
#endif

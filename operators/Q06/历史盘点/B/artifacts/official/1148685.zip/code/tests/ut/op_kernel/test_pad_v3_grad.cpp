/*!
 * \file test_pad_v3_grad.cpp
 * \brief PadV3Grad 算子 kernel UT 测试
 * 
 * 独立运行，直接构造 tilingData，不依赖 op_host UT
 */

#include "pad_v3_grad_tiling.h"
#include "../../../op_kernel/pad_v3_grad.cpp"

#include <array>
#include <vector>
#include <iostream>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include "gtest/gtest.h"
#include "tikicpulib.h"

using namespace std;

static uint16_t FloatToHalf(float f) {
    uint32_t bits;
    memcpy(&bits, &f, sizeof(float));
    uint32_t sign = (bits >> 16) & 0x8000;
    int32_t exp = ((bits >> 23) & 0xff) - 127 + 15;
    uint32_t mant = (bits >> 13) & 0x3ff;
    if (exp <= 0) return sign;
    if (exp >= 31) return sign | 0x7c00;
    return sign | (exp << 10) | mant;
}

static uint16_t FloatToBFloat16(float f) {
    uint32_t bits;
    memcpy(&bits, &f, sizeof(float));
    return (uint16_t)(bits >> 16);
}

class PadV3GradKernelTest : public testing::Test {
protected:
    static void SetUpTestCase()
    {
        cout << "PadV3GradKernelTest SetUp" << endl;
    }
    static void TearDownTestCase()
    {
        cout << "PadV3GradKernelTest TearDown" << endl;
    }
};

TEST_F(PadV3GradKernelTest, test_kernel_run)
{
    constexpr size_t size = 64;
    constexpr size_t tilingDataSize = sizeof(PadV3GradTilingData);
    constexpr uint32_t numBlocks = 1;

    constexpr size_t xByteSize = 64 * 4;
    constexpr size_t paddingsByteSize = 8 * 4;
    constexpr size_t yByteSize = 16 * 4;
    std::vector<uint8_t> xHost(xByteSize);
    std::vector<uint8_t> paddingsHost(paddingsByteSize);
    std::vector<uint8_t> yHost(yByteSize);
    
    
    ASSERT_NE(std::getenv("SAMPLE_DIR"), nullptr);
    const std::string root = std::getenv("SAMPLE_DIR");
    uint8_t* x = (uint8_t*)AscendC::GmAlloc(xByteSize);
    uint8_t* paddings = (uint8_t*)AscendC::GmAlloc(paddingsByteSize);
    uint8_t* y = (uint8_t*)AscendC::GmAlloc(yByteSize);
    uint8_t* workspace = (uint8_t*)AscendC::GmAlloc(32);
    uint8_t* tiling = (uint8_t*)AscendC::GmAlloc(tilingDataSize);
    
    { std::ifstream f(root + "/input/x.bin", std::ios::binary); ASSERT_TRUE(f.good()); f.read(reinterpret_cast<char*>(x), 256); ASSERT_EQ(f.gcount(), 256); }
    { std::ifstream f(root + "/input/paddings.bin", std::ios::binary); ASSERT_TRUE(f.good()); f.read(reinterpret_cast<char*>(paddings), 32); ASSERT_EQ(f.gcount(), 32); }
    
    // TODO: 以下 tilingData 字段基于初始模板的 TilingData 结构。
    //       修改 TilingData 结构后请更新字段名和赋值：
    //         参考 op_kernel/pad_v3_grad_tiling_data.h 中的字段定义
    //         参考 op_host/pad_v3_grad_tiling.cpp 中的 tiling 计算逻辑
    PadV3GradTilingData* tilingData = reinterpret_cast<PadV3GradTilingData*>(tiling);
    tilingData->totalNum = size;
    tilingData->blockFactor = size;
    tilingData->ubFactor = size;
    
    // TODO: tilingKey 应与 op_host/pad_v3_grad_tiling.cpp 中 SetTilingKey 设置的值一致
    ICPU_SET_TILING_KEY(1);
    AscendC::SetKernelMode(KernelMode::AIV_MODE);
    
    ICPU_RUN_KF((pad_v3_grad<1>), numBlocks, x, paddings, y, workspace, tiling);
    
    // 将动态输出的 packed buffer 拆回 individual buffers
    
    
    // 将 output 数据保存到 bin 文件供 compare_data.py 比对
    memcpy(yHost.data(), y, yByteSize);
    { std::ofstream _ofs((root + "/output/y.bin"), std::ios::binary); _ofs.write(reinterpret_cast<const char*>(yHost.data()), yByteSize); }
    
    AscendC::GmFree(x);
    AscendC::GmFree(paddings);
    AscendC::GmFree(y);
    AscendC::GmFree(workspace);
    AscendC::GmFree(tiling);
}
